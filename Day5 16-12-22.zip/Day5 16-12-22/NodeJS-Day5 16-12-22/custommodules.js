var username="suraj";
var brands=["addidas","nike"]
var userinfo={age:20}
var userrole=function(){
    return "java Developer";
}

module.exports={username,brands,userinfo,userrole};